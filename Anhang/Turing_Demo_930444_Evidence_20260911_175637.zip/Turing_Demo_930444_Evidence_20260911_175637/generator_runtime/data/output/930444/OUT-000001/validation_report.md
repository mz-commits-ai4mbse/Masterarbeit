# SysML v2 Validation Report

- Project: `930444`
- Source IEM: `IEM-000002`
- Validation status: **valid**
- Publication gate: **passed**
- Artifact set fingerprint: `217e89b7e5c37a39842f0479076e3389a0c4b8de0847706b6d84cd77a9ff730c`
- Validation result fingerprint: `aa196bed0529b592c28b3b61d18924b31167d56571f9837f900f6ae48deb4fae`
- Validation profile: `TURING_SYSML_V2_VALIDATION 1.0.0`
- Findings: 0

## External validator evidence

- `SYSIDE_CLI` — SYSIDE Modeler CLI syside 0.10.3 (b6e216cb48b5336ea48283e99c68a0e10e17b8cc); execution=completed; diagnostics=0

## Findings

No validation findings.
