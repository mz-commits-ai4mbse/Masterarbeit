# Stakeholders

The Microscope Operator is the local user.

The Remote Expert is the remote user.
