# Product Context

iO Stream supports remote collaboration in digital microscopy.
The main users are a Microscope Operator and a Remote Expert.
