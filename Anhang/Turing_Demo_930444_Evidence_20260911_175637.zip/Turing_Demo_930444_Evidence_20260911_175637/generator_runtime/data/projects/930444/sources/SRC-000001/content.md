# Product Context

iO Stream supports remote collaboration in digital microscopy.

A Microscope Operator works locally and a Remote Expert participates remotely.
