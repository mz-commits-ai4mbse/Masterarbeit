# Architecture Notes

The Microscope Workstation provides local session control.

The Remote Client provides remote viewing and control requests.
