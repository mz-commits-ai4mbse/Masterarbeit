# User Workflow

1. The Microscope Operator starts the collaboration session.
2. The Remote Expert requests microscope control.
3. The Microscope Operator may take back control.
