# System Requirements

The system shall indicate the current controller.

The system shall disable remote control after connection loss.

The system shall return control to the Microscope Operator after connection loss.
